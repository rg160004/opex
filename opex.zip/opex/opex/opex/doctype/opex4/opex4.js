// Copyright (c) 2022, OpEX Team and contributors
// For license information, please see license.txt

const ignoredFields = [
  'creation',
  'docstatus',
  'doctype',
  'idx',
  'modified',
  'modified_by',
  'name',
  'owner',
  'parent',
  'parentfield',
  'parenttype',
  'bcsla_code',
]

const formStatuses = {
  EXITED: 'Exited',
  REVIEWED: 'Reviewed',
  INITIATED: 'Initiated',
}

//Global vars
let cell,
  prevPracticeName,
  isLastIndex = null
let isExSelectionNegative,
  isWoExSelectionNegative = false,
  isExit = false,
  isReview = false
let totalExAvg = 0,
  totalWoExAvg = 0
let nNonSelecion = 0,
  totalPracticeCount = 0,
  tablePracticeCount = 0,
  totalRowsCount = 0,
  totalAccountCount = 0,
  totalEvidence = 0,
  nEvidence = 0,
  nEvAccepted = 0
let practiceTableRows = [],
  moduleAvgTableRows = []
let isNotApplicable = false,
  isNoEvidence = false,
  isPracticeEmpty = false,
  isNegativeAndCritical = false,
  napCount = 0,
  isEmptySelection = false
const exMaturitySet = new Set()
const woExmaturitySet = new Set()
let findingsDataMap = {}

const selectionTypesWithEx = {
  Yes: 1,
  Exception: 1,
  'Not Applicable': 1,
  No: 0,
  '-': null,
  'No Sample': 1,
  'No Evidence': 0,
}
const selectionTypesWoEx = {
  Yes: 1,
  Exception: 0,
  'Not Applicable': 1,
  No: 0,
  '-': null,
  'No Sample': 0,
  'No Evidence': 0,
}
const maturityScoresMap = {
  LAGGING: 1,
  INITIAL: 2,
  'DEFINED & DEVELOPING': 3,
  ESTABLISHED: 4,
  LEADING: 5,
}

const getPlannerDocName = frm =>
  `${frm.doc.client_name}-${frm.doc.processlob}-${frm.doc.bcsla_code}-${frm.doc.intervention_type}`

const resetGlVars = isCell => {
  exMaturitySet.clear()
  woExmaturitySet.clear()
  if (!isCell) {
    cell = null
    isLastIndex = null
    isExSelectionNegative = false
    isWoExSelectionNegative = false
  }
  prevPracticeName = null
}

const isSelNotApplicable = selection =>
  selection === 'Not Applicable' || selection === 'Exception'

const isSelNoEvidence = selection => selection === 'No Evidence'

const isSelNegOrEmpty = cell =>
  (cell.selection === '-' ||
    cell.selection === 'No' ||
    cell.selection === 'No Evidence') &&
  cell.critical_to_opex === 'Yes'

const calculateResult = (
  cell,
  maturitySet,
  selectionType,
  result,
  isExceptionType,
  shouldReset
) => {
  //Check if it reaches another practice group -> reset all values
  if (prevPracticeName !== cell.practice || isLastIndex) {
    const selection = selectionType[cell.selection]
    if (!isEmptySelection) isEmptySelection = selection === null
    //Check and add current maturity_level at last index
    if (
      isLastIndex &&
      selection &&
      !(isExceptionType ? isExSelectionNegative : isWoExSelectionNegative)
    )
      maturitySet.add(cell.maturity_level)
    //Assign result to practice group
    if (prevPracticeName) {
      const matList = [...maturitySet]
      // console.log(prevPracticeName, isCritical, isNegativeOrEmpty)
      const finalMatLevel = isPracticeEmpty
        ? 'No Evidence'
        : isNegativeAndCritical
        ? 'LAGGING'
        : !matList.length
        ? 'No Evidence'
        : (isExceptionType ? isExSelectionNegative : isWoExSelectionNegative)
        ? matList[matList.length - 2] ?? 'LAGGING'
        : matList[matList.length - 1]
      result[
        isLastIndex && !prevPracticeName ? cell.practice : prevPracticeName
      ] = {
        score:
          isNotApplicable || isNoEvidence
            ? 0
            : maturityScoresMap[finalMatLevel] || 0,
        maturity_level: isNotApplicable
          ? 'Not Applicable'
          : isNoEvidence
          ? 'No Evidence'
          : finalMatLevel,
      }
      maturitySet.clear()
      if (shouldReset) {
        isEmptySelection = false
        if (!isNotApplicable) {
          totalPracticeCount++
          tablePracticeCount++
        }
        isNotApplicable = isSelNotApplicable(cell.selection)
        isNoEvidence = isSelNoEvidence(cell.selection)
        isNegativeAndCritical = isSelNegOrEmpty(cell)
        isPracticeEmpty = cell.selection === '-'
      }
    }

    if (!selection && selection !== null) maturitySet.add(cell.maturity_level)

    if (isExceptionType) isExSelectionNegative = !selection
    else isWoExSelectionNegative = !selection
  }
  //If selection is positive
  if (
    !(isExceptionType ? isExSelectionNegative : isWoExSelectionNegative) &&
    selectionType[cell.selection]
  )
    maturitySet.add(cell.maturity_level)
  //If selection is negative
  else {
    if (!(isExceptionType ? isExSelectionNegative : isWoExSelectionNegative)) {
      maturitySet.add(cell.maturity_level)
      if (isExceptionType) isExSelectionNegative = true
      else isWoExSelectionNegative = true
    }
  }
}

const getModuleName = module =>
  module.replace('_table', '').split('_').join(' ')

const populateFindings = (module, rows, frm) => {
  module = getModuleName(module)
  let keyName
  for (let row of rows) {
    keyName = null
    if (row.selection === 'No') keyName = row.severity
    else if (row.selection === 'No Evidence') keyName = row.selection
    else if (row.selection === 'Exception') keyName = 'Exceptions'

    if (keyName) {
      if (row.selection === 'No' || row.selection === 'No Evidence') {
        row.finding = 'yes'
        if (frm.doc.form_status === formStatuses.EXITED || isExit) {
          if (!row.finding_raised_date)
            row.finding_raised_date = frappe.datetime.get_today()
        }
        row.ageing = row.finding_raised_date
          ? frappe.datetime.get_day_diff(
              frappe.datetime.get_today(),
              row.finding_raised_date
            )
          : 0
      }
      const v = { ...row, module }
      if (!findingsDataMap[keyName]) findingsDataMap[keyName] = [v]
      else findingsDataMap[keyName].push(v)
    }
  }
}

const analyzeCells = (tableName, cells, frm) => {
  const resultWIthEx = {}
  const resultWoEx = {}
  tablePracticeCount = 0
  resetGlVars()
  if (cells && cells.length) {
    let cell
    for (let cIdx in cells) {
      cell = cells[cIdx]
      if (cell) {
        isLastIndex = cIdx == cells.length - 1

        if ((isLastIndex && isNotApplicable) || !prevPracticeName)
          isNotApplicable = isSelNotApplicable(cell.selection)

        if ((isLastIndex && isNoEvidence) || !prevPracticeName)
          isNoEvidence = isSelNoEvidence(cell.selection)

        if ((isLastIndex && !isNegativeAndCritical) || !prevPracticeName)
          isNegativeAndCritical = isSelNegOrEmpty(cell)

        if ((isLastIndex && isPracticeEmpty) || !prevPracticeName)
          isPracticeEmpty = cell.selection === '-'

        // if ((isLastIndex && isCritical) || !prevPracticeName)
        //   isCritical = cell.critical_to_opex === 'Yes'

        calculateResult(
          cell,
          exMaturitySet,
          selectionTypesWithEx,
          resultWIthEx,
          true
        )
        calculateResult(
          cell,
          woExmaturitySet,
          selectionTypesWoEx,
          resultWoEx,
          false,
          true
        )
        prevPracticeName = cell.practice
        //Check if all rows in a group is Not Applicable
        if (isNotApplicable)
          isNotApplicable = isSelNotApplicable(cell.selection)
        if (isNoEvidence) isNoEvidence = isSelNoEvidence(cell.selection)
        if (!isNegativeAndCritical)
          isNegativeAndCritical = isSelNegOrEmpty(cell)
        if (isPracticeEmpty) isPracticeEmpty = cell.selection === '-'

        // if (isCritical) isCritical = cell.critical_to_opex === 'Yes'
      }
      if (cell.selection === '-') nNonSelecion++

      totalRowsCount++
    }
    populateFindings(tableName, cells, frm)
  }
  let exAvg = 0,
    woExAvg = 0
  Object.keys(resultWIthEx).forEach(k => {
    const row = {
      practice: k,
      maturity_level_exception: resultWIthEx[k].maturity_level,
      maturity_level_wo_exception: resultWoEx[k].maturity_level,
      score_exception: resultWIthEx[k].score,
      score_wo_exception: resultWoEx[k].score,
    }
    practiceTableRows.push(row)
    exAvg += row.score_exception
    woExAvg += row.score_wo_exception
    totalExAvg += row.score_exception
    totalWoExAvg += row.score_wo_exception
    if (row.maturity_level_exception != 'Not Applicable') totalAccountCount++
  })
  exAvg = ((exAvg / tablePracticeCount) * 2).toFixed(2)
  woExAvg = ((woExAvg / tablePracticeCount) * 2).toFixed(2)
  moduleAvgTableRows.push({
    module: getModuleName(tableName),
    score_exception: exAvg,
    score_wo_exception: woExAvg,
  })
}

const makeModuleMap = (list, keyName) => {
  const m = {}
  list.forEach(v => {
    m[v[keyName]] = v
  })
  return m
}

const startAnalyzing = async frm => {
  // if (frm.is_new() || !frm.is_dirty()) {
  //   console.log('Nothing to analyze')
  //   return
  // }
  const timeStamp = new Date().getTime()
  console.log('Started at ', new Date(timeStamp))
  //Reset Vars
  nNonSelecion = 0
  totalRowsCount = 0
  totalPracticeCount = 0
  totalAccountCount = 0
  totalExAvg = 0
  totalWoExAvg = 0
  practiceTableRows = []
  moduleAvgTableRows = []

  if (frm && frm.doc) {
    const doc = frm.doc
    Object.keys(doc).forEach(k => {
      const cells = doc[k]
      if (k.includes('_table') && !k.includes('artifact'))
        analyzeCells(k, cells, frm)
      if (k.includes('artifact')) {
        if (cells && cells.length)
          cells.forEach(d => {
            totalEvidence++
            if (d.attach_files) nEvidence++
            if (d.accepted_status === 'Accepted') nEvAccepted++
          })
      }
    })
    //Findings table calculation start
    Object.keys(findingsDataMap).forEach(severity => {
      const rows = findingsDataMap[severity]
      severity = severity.toLowerCase().split(' ').join('_')
      // console.log(severity, rows);
      if (severity in frm.doc && rows && rows.length) {
        frm.clear_table(severity)
        rows.forEach(r => {
          frm.add_child(severity, r)
        })
      }
    })
    findingsDataMap = {}
    //Findings table calculation end

    const completionAvg = (nNonSelecion / totalRowsCount) * 100

    frm.set_value('form_completion', `${(100.0 - +completionAvg).toFixed(2)}%`)
    frm.set_value(
      'evidence_shared',
      `${((nEvidence / totalEvidence) * 100).toFixed(2)}%`
    )
    frm.set_value(
      'evidence_accepted',
      `${((nEvAccepted / totalEvidence) * 100).toFixed(2)}%`
    )
    // console.log('Evidence shared -> ', nEvidence, totalEvidence);
    if (!isNaN(totalExAvg))
      frm.set_value(
        'account_score_exception',
        ((totalExAvg / totalAccountCount) * 20).toFixed(2)
      )
    if (!isNaN(totalWoExAvg))
      frm.set_value(
        'account_score_wo_exception',
        ((totalWoExAvg / totalAccountCount) * 20).toFixed(2)
      )
    // console.log('module score list - ', moduleAvgTableRows);
    if (
      !(frm.doc.practice_score && frm.doc.practice_score.length) ||
      !(frm.doc.module_score && frm.doc.module_score.length)
    ) {
      cur_frm.clear_table('practice_score')
      cur_frm.clear_table('module_score')
      practiceTableRows.forEach(r => {
        frm.add_child('practice_score', r)
      })
      moduleAvgTableRows.forEach(r => {
        frm.add_child('module_score', r)
      })
    } else {
      console.log('Data exists!')
      const moduleScoreMap = makeModuleMap(frm.doc.module_score, 'module')
      const practiceScoreMap = makeModuleMap(frm.doc.practice_score, 'practice')
      practiceTableRows.forEach(r => {
        const rowRef = practiceScoreMap[r.practice]
        if (!rowRef) frm.add_child('practice_score', r)
        else
          Object.keys(r).forEach(k => {
            rowRef[k] = r[k]
          })
      })
      moduleAvgTableRows.forEach(r => {
        const rowRef = moduleScoreMap[r.module]
        if (!rowRef) frm.add_child('module_score', r)
        else
          Object.keys(r).forEach(k => {
            rowRef[k] = r[k]
          })
      })
    }
    if (isExit || isReview) {
      frm.trigger('perform_exit')
    }

    frm.refresh_fields()
    console.log('Data analyzed in ', new Date().getTime() - timeStamp, ' ms')
    frm.save()
  }
}

//------------------INIT STUFF-------------------------

const loadingStates = {}

const initConfigList = [
  {
    identifier: 'table',
    blacklistedFields: ['module'],
    args: {
      doctype: 'Opex Form Library',
      fields: [
        'practice',
        'module',
        'question',
        'opportunity_description',
        'gdp_clause',
        'iso_clause',
        'cms',
        'severity',
        'dfi',
        'maturity_level',
        'guidelines_direction',
        'artifact_description',
      ],
      order_by: 'practice',
    },
  },
  {
    identifier: 'artifact',
    blacklistedFields: ['module'],
    args: {
      doctype: 'Opex File Library',
      fields: [
        'practice',
        'module',
        'artifacts',
        'evidence_list_description',
        'primary_ownership',
      ],
      order_by: 'practice',
    },
  },
]

const checkAndSaveForm = frm => {
  const shouldSave = Object.values(loadingStates).every(v => !v)
  if (shouldSave) {
    frm.enable_save()
    frm.set_value('form_status', formStatuses.INITIATED)
    frm.set_value('initialized', 1)
    frm.refresh_fields()
    frm.trigger('calculate_data')
    // frm.save()
  }
}

function onDataRecievedCB({ message: data }) {
  // console.log(data);
  if (data && data.length) {
    const childDataMap = {}
    data.forEach(row => {
      if (childDataMap[row.module]) childDataMap[row.module].push(row)
      else childDataMap[row.module] = [row]
    })
    // console.log('module map obj:', childDataMap);
    if (this.frm && this.tables) {
      console.log('Initiating Tables!', this.tables)
      const config = this.config
      if (config.blacklistedFields) {
        // let rowToAdd = {}
        this.tables.forEach(tableKey => {
          const rows = childDataMap[tableKey]
          if (rows && rows.length)
            rows.forEach(row => {
              const rowToAdd = { ...row }
              config.blacklistedFields.forEach(rowKey => {
                delete rowToAdd[rowKey]
              })
              this.frm.add_child(tableKey, rowToAdd)
            })
          this.frm.refresh_field(tableKey)
        })
      }
    }
  }
  console.log('Initiating Completed!', this.config.identifier)
  loadingStates[this.config.identifier] = false
  checkAndSaveForm(this.frm)
}

function handleFormSetup(frm) {
  const tablesMap = {}
  const identifiers = initConfigList.map(c => c.identifier)
  // console.log(frm,frm.doc);
  if (frm && frm.doc) {
    Object.keys(frm.doc).forEach(k => {
      const temp = identifiers.find(id => k.includes(id))
      if (temp) {
        if (tablesMap[temp]) tablesMap[temp].push(k)
        else tablesMap[temp] = [k]
      }
    })
    initConfigList.forEach(config => {
      loadingStates[config.identifier] = true
      const bound = { frm, tables: tablesMap[config.identifier], config }
      frappe.call({
        method: 'frappe.client.get_list',
        args: config.args,
        callback: onDataRecievedCB.bind(bound),
      })
    })
    const today = frappe.datetime.get_today()
    frm.set_value('actual_start_date', today)
    frm.set_value('planned_end_date', frappe.datetime.add_days(today, 45))
    frm.set_value(
      'evidence_collection_end_date',
      frappe.datetime.add_days(today, 10)
    )
    frm.refresh_fields()
  }
}

// const populateFindingBank = frm => {
// 	const findings_table = []
// 	if (frm && frm.doc) {
// 		Object.keys(frm.doc).forEach(tableName => {
// 			if (tableName && tableName.includes('_table')) {
// 				const module = tableName.split('_table')[0]
// 				for (let row of frm.doc[tableName]) {
// 					if (row.selection === 'No') {
// 						const data = Object.assign({}, row)
// 						const ref_id = `${data.name}`
// 						delete data.idx
// 						delete data.__unsaved
// 						delete data.creation
// 						delete data.docstatus
// 						delete data.doctype
// 						delete data.modified
// 						delete data.modified_by
// 						delete data.name
// 						findings_table.push({
// 							ref_id,
// 							...data,
// 							module
// 						})
// 					}
// 				}
// 			}

// 		});
// 		// console.log(findings_table)
// 		frappe.call({
// 			method: 'frappe.client.insert',
// 			args: {
// 				doc: {
// 					doctype: 'Finding Bank',
// 					parent_table_ref: frm.doc.name,
// 					findings_table
// 				}
// 			},
// 			callback: data => {
// 				console.log('Insert success', data);
// 			},
// 		});
// 	}

// }

const performExit = frm => {
  const fieldStr = isExit ? 'exit' : isReview ? 'review' : ''
  frm.set_value(
    `account_score_${fieldStr}_exception`,
    frm.doc.account_score_exception
  )
  frm.set_value(
    `account_score_${fieldStr}_wo_exception`,
    frm.doc.account_score_wo_exception
  )

  frm.doc.module_score.forEach(row => {
    row[`${fieldStr}_score_exception`] = row.score_exception
    row[`${fieldStr}_score_wo_exception`] = row.score_wo_exception
  })
  frm.doc.practice_score.forEach(row => {
    row[`${fieldStr}_score_exception`] = row.score_exception
    row[`${fieldStr}_score_wo_exception`] = row.score_wo_exception
    row[`${fieldStr}_maturity_level_exception`] = row.maturity_level_exception
    row[`${fieldStr}_maturity_level_wo_exception`] =
      row.maturity_level_wo_exception
  })
  Object.keys(frm.doc).forEach(tableName => {
    if (tableName.includes('_table'))
      frm.doc[tableName].forEach(row => {
        row[`${fieldStr}_selection`] = row.selection
      })
  })

  const docName = getPlannerDocName(frm)
  frappe.db.set_value(
    'OpEx Planner',
    docName,
    'status',
    isExit ? 'Exited' : isReview ? 'Reviewed' : ''
  )

  frm.refresh_fields()
  isExit = false
  isReview = false
}
const removeGridButtons = (frm, hasPerm) => {
  //Hide last 3 attach buttons
  $('.timeline-actions').hide()
  $('[data-fieldname="attach_files"]').mouseup(() => {
    setTimeout(() => {
      $('button[data-fieldname="attach_files"]').click(() => {
        setTimeout(() => {
          $('.btn-file-upload:nth-child(n+2)').hide()
          $('.btn-modal-secondary').hide()
        }, 200)
      })
    }, 0)
  })

  if (frm.doc) {
    //Disable drag n drop
    $('.sortable-handle').removeClass('sortable-handle')
    //Hide row check button
    $('.row-check').hide()
    //Hide column setting button
    // $('.grid-static-col > a').parent().hide()

    $.find('.btn-open-row').forEach(g => {
      $(g).click(() => {
        $('.grid-footer-toolbar').hide()
        $('.row-actions').hide()
      })
    })
    Object.keys(frm.doc).forEach(k => {
      if (/table|artifact/g.test(k)) {
        const field = frm.get_field(k)
        // frm.set_df_property('remarks', 'read_only', 1, frm.docname, k)
        field.grid.grid_buttons.hide()
        if (k.includes('artifact')) {
          field.grid.docfields.forEach(f => {
            if (
              (hasPerm
                ? ['accepted_status', 'remarks']
                : ['attach_files', 'comments_as_per_account']
              ).includes(f.fieldname)
            )
              return
            f.read_only = 1
          })
        }
      }
    })
    frm.refresh_fields()
  }
}
const onFormRefresh = frm => {
  // console.log('Refreshing...', frm)
  const isAllowed = frm.perm && frm.perm.some(p => p.permlevel === 1)
  removeGridButtons(frm, isAllowed)
  if (!isAllowed) {
    frm.page.sidebar.hide()
    return
  }
  if (!frm.is_new()) {
    if (!frm.doc.initialized)
      frm.add_custom_button(
        'Initiate',
        () => {
          frm.disable_save()
          frm.remove_custom_button('Initiate', 'Actions')
          frm.trigger('refresh_process')
          frm.trigger('initiate_data')
          frm.trigger('initiate_opex_planner')
        },
        'Actions'
      )
    else {
      // frm.add_custom_button('Refresh Ageing', () => {
      // 	frm.trigger('calculate_ageing')
      // })
      if (!frm.doc.exited)
        frm.add_custom_button('Publish Exit', () => {
          frappe.confirm('Are you sure you want to Exit?', () => {
            isExit = true
            frm.trigger('calculate_data')
            frm.set_value('form_status', formStatuses.EXITED)
            frm.set_value('exit_report_date', frappe.datetime.get_today())
            frm.set_value('exited', 1)
            frm.remove_custom_button('Exit')
            frm.save()
          })
        })
      if (frm.doc.exited && !frm.doc.reviewed)
        frm.add_custom_button('Publish Review', () => {
          frappe.confirm('Are you sure you want to Review?', () => {
            isReview = true
            frm.trigger('calculate_data')
            frm.set_value('form_status', formStatuses.REVIEWED)
            frm.set_value('review_report_date', frappe.datetime.get_today())
            frm.set_value('reviewed', 1)
            frm.remove_custom_button('Review')
            frm.save()
          })
        })
      frm.add_custom_button('Refresh Process Details', () => {
        frm.trigger('refresh_process')
      })
      frm.add_custom_button('Refresh Score', () => {
        frappe.confirm('Proceed to calculate scores?', () => {
          frm.trigger('calculate_data')
        })
      })
    }
  }
}

const calculateAgeing = frm => {
  console.log('Form loaded...')
  frm.set_value('current_date', new Date())
  // Object.keys(frm.doc).forEach(k => {
  // 	if (k.includes('_table') && !k.includes('artifact')) {
  // 		for (let row of frm.doc[k]) {
  // 			if ((row.selection === 'No' || row.selection === 'No Evidence')) {
  // 				row.ageing = row.finding_raised_date ?
  // 					parseInt((new Date().getTime() - new Date(row.finding_raised_date).getTime()) / 86400000)
  // 					: 0
  // 			}
  // 		}
  // 	}
  // })
  // frm.refresh_fields()
  frm.save()
}

const refreshProcessDetails = frm => {
  const name = frm.doc.bcsla_code
  // console.log('bcsla code: ', name)
  frappe.call({
    method: 'frappe.client.get',
    args: {
      doctype: 'Oracle Master',
      name,
    },
    callback: data => {
      const values = data.message
      if (values) {
        Object.keys(values).forEach(k => {
          if (values[k] && !ignoredFields.includes(k))
            frm.set_value(k, values[k])
        })
        frm.refresh_fields()
      }
    },
  })
}

const initiatePlanner = frm => {
  const docName = getPlannerDocName(frm)
  frappe.db.set_value('OpEx Planner', docName, 'status', 'Initiated')
  // console.log('Hello Planner--->', d, frappe);
}

frappe.ui.form.on('OpEx4', {
  // before_save: startAnalyzing,
  calculate_data: startAnalyzing,
  refresh: onFormRefresh,
  initiate_data: handleFormSetup,
  // before_submit: populateFindingBank,
  perform_exit: performExit,
  // onload: calculateAgeing,
  refresh_process: refreshProcessDetails,
  initiate_opex_planner: initiatePlanner,
})
